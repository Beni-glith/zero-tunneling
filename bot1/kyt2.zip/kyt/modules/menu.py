from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline("𝚂𝚜𝚑", "ssh")],
        [Button.inline("𝚅𝚖𝚎𝚜𝚜", "vmess")],
        [Button.inline("𝚅𝚕𝚎𝚜𝚜", "vless")],
        [Button.inline("𝚃𝚛𝚘𝚓𝚊𝚗", "trojan")],
        [Button.inline("𝚂𝚑𝚊𝚍𝚘𝚠𝚜𝚘𝚌𝚔𝚜", "shadowsocks")],
        [Button.inline("𝙽𝚘𝚘𝚋𝚣𝚟𝚙𝚗𝚜", "noobzvpns")],
        [Button.inline("𝙲𝚑𝚎𝚌𝚔 𝚅𝙿𝚂 𝙸𝚗𝚏𝚘", "info"),
        Button.inline(" ‹ 𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞 › ", "start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' cat /etc/passwd | grep "home" | grep "false" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		shadowsocks = subprocess.check_output('cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")

		msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨🔸𝙻𝚒𝚝𝚎 𝚂𝚝𝚘𝚛𝚎 𝚅𝙿𝙽 𝙱𝚘𝚝🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» 𝙾𝚜**     : `{namaos.strip().replace('"','')}`
**» 𝙳𝚘𝚖𝚊𝚒𝚗**: `{DOMAIN}`
**» 𝙸𝙿 𝙰𝚍𝚍𝚛𝚎𝚜**: `{ipsaya.strip()}`
**» 𝚃𝚘𝚝𝚊𝚕 𝙰𝚌𝚌𝚘𝚞𝚗𝚝**: 

**»🔸𝚂𝚜𝚑**: `{ssh.strip()}` __account__
**»🔸𝚅𝚖𝚎𝚜𝚜**: `{vms.strip()}` __account__
**»🔸𝚅𝚕𝚎𝚜𝚜**: `{vls.strip()}` __account__
**»🔸𝚃𝚛𝚘𝚓𝚊𝚗**: `{trj.strip()}` __account__
**»🔸𝚂𝚑𝚊𝚍𝚘𝚠𝚜𝚘𝚌𝚔𝚜**: `{shadowsocks.strip()}` __account__
**◇━━━━━━━━━━━━━━━━━◇**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)


